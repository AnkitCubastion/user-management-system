import React from "react";
import "./errorElement.css";

const ErrorElement = () => {
  return <div className="error-container"></div>;
};

export default ErrorElement;
